# Experiment 10: Static Binary Analysis Using Ghidra

This experiment records non-executing inspection of an instructor-approved binary in Ghidra. The analysis differentiates observed code artefacts from claims about runtime behaviour.

![Ghidra workflow](assets/workflow.svg)

## Aim

Hash a benign training binary, import it into a non-shared Ghidra project, inspect strings and imports, trace code references, and document findings with addresses.

## Workflow

1. Hash the training sample and keep it in an isolated analysis environment.
2. Import the sample into a non-shared Ghidra project and record the detected architecture.
3. Run auto-analysis, then review Defined Strings, Imports, Listing, Decompiler, and Function Graph views.
4. Log observed facts, the analyst interpretation, confidence, and a validation step.

```text
sha256sum training-sample.bin
File > New Project > Non-Shared Project
File > Import File > open in CodeBrowser > Auto Analyze
Window > Defined Strings; Symbol Tree > Imports; Window > Function Graph
```

## Evidence to record

- File hash, size, architecture, file format, and Ghidra version.
- Relevant strings, imports, cross-references, and code addresses.
- The distinction between observed facts and proposed behaviour.
- Analysis-environment controls proving the sample was not executed.

## Result

The results document produces an addressable and reproducible static-analysis record while avoiding unsupported conclusions about the binary's actual runtime actions.

See the accompanying [results PDF](Experiment-10-Results.pdf).
