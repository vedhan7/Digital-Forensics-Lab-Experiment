# Experiment 7: Android Logical Acquisition Using AFLogical OSE

This experiment documents the logical acquisition of active Android artefacts from an authorised test device. The acquisition scope is limited by Android permissions and the data providers selected during collection.

![AFLogical OSE workflow](assets/workflow.svg)

## Aim

Establish an ADB connection, collect approved logical artefacts with AFLogical OSE, preserve the export, and record hashes for the received files.

## Workflow

1. Confirm USB debugging and device authorisation with `adb devices`.
2. Install AFLogical OSE on the authorised lab device.
3. Select approved providers such as Contacts, Call Log, SMS/MMS, and Device Information.
4. Pull the acquisition folder to a case directory and hash the original export.

```text
adb devices
adb install aflogical-ose.apk
adb pull /sdcard/forensics/ C:\Case001\logical-acquisition\
Get-FileHash C:\Case001\logical-acquisition\* -Algorithm SHA256
```

## Evidence to record

- Device serial, time zone, operator, and collection time.
- Provider selections and AFLogical OSE / ADB version.
- Artifact names, hashes, and storage location.
- Any permissions or artefact categories unavailable through logical acquisition.

## Result

The result record demonstrates a repeatable logical-acquisition process and preserves the context required to interpret the exported contacts, messages, call-log, and device-information files.

See the accompanying [results PDF](Experiment-07-Results.pdf).
