# Experiment 9: Live Process Triage Using Process Explorer

This experiment establishes a safe, evidence-first method for investigating processes on an authorised Windows lab system. Unusual process features are recorded as indicators and verified before containment.

![Process Explorer workflow](assets/workflow.svg)

## Aim

Use Process Explorer to document process lineage, image metadata, digital signatures, loaded DLLs, and approved reputation-lookup results.

## Workflow

1. Run Process Explorer in the authorised lab VM with the required permissions.
2. Inspect the parent-child process tree and record selected process identifiers.
3. Review the Image properties, signature state, path, command line, and loaded DLLs.
4. Preserve evidence before applying any containment or remediation action.

```text
Properties > Image: record path, signer, command line, and hash
Options > VirusTotal.com > Check VirusTotal.com (if approved)
View > Lower Pane View > DLLs
```

## Evidence to record

- PID, parent PID, account, start time, and observed process lineage.
- Executable path, signer, file hash, command line, and relevant DLLs.
- Reputation-lookup time and result only where policy allows the lookup.
- Preservation and escalation decision before a process is suspended or terminated.

## Result

The record converts live observations into evidence points that can be validated through signatures, image metadata, process lineage, and approved threat-intelligence sources.

See the accompanying [results PDF](Experiment-09-Results.pdf).
