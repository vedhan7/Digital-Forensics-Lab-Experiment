# Experiment 8: Steganography Triage Using StegExpose

This experiment applies StegExpose to a controlled image set. A score supports prioritisation; it does not independently prove hidden content.

![StegExpose workflow](assets/workflow.svg)

## Aim

Hash the image set, run the StegExpose scan with a documented threshold, preserve the output, and identify samples requiring corroborating analysis.

## Workflow

1. Preserve and hash the controlled source images.
2. Record the Java and StegExpose versions and the selected threshold.
3. Scan the evidence folder and save the result file.
4. Compare flagged images with clean controls and validate with independent checks.

```bash
sha256sum Evidence/* > evidence-hashes.sha256
java -version
java -jar StegExpose.jar Evidence default 0.20 report.csv
exiftool Evidence/suspect.png
```

## Evidence to record

- File name, SHA-256, format, dimensions, and source set.
- Tool version, command line, threshold, and raw score.
- The reason a sample was retained, reviewed, or escalated.
- Any corroborating result before reporting a final conclusion.

## Result

The resulting report ties every triage score to a specific hashed sample and an auditable decision, avoiding unsupported conclusions based solely on one statistical measure.

See the accompanying [results PDF](Experiment-08-Results.pdf).
