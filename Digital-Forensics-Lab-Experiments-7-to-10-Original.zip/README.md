# Digital Forensics Laboratory

Original documentation and result records for Experiments 7-10. The reports follow a consistent laboratory structure while preserving the distinction between a workflow reference and evidence obtained during an authorised practical run.

| Experiment | Topic | README | Results PDF |
| --- | --- | --- | --- |
| 7 | Android logical acquisition using AFLogical OSE | [Open](EXP-7/README.md) | [Open](EXP-7/Experiment-07-Results.pdf) |
| 8 | Steganography triage using StegExpose | [Open](EXP-8/README.md) | [Open](EXP-8/Experiment-08-Results.pdf) |
| 9 | Live process triage using Process Explorer | [Open](EXP-9/README.md) | [Open](EXP-9/Experiment-09-Results.pdf) |
| 10 | Static binary analysis using Ghidra | [Open](EXP-10/README.md) | [Open](EXP-10/Experiment-10-Results.pdf) |

## Evidence discipline

The included workflow graphics are original explanatory diagrams, not substituted screenshots. Add only screenshots captured from your own authorised lab work, record the tool version and time zone, and retain hashes for every acquired or analysed file.
